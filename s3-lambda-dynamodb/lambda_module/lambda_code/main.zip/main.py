
def post_to_db(event, context):
    return "success"

